package org.example.charityapp.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Partenaire {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;

    private String type; // ONG, Entreprise, etc.

    private String siteWeb;

    private String logoUrl;

    private String description;
}
