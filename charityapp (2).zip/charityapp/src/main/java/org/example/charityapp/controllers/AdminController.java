package org.example.charityapp.controllers;

import org.example.charityapp.entities.ActionCharite;
import org.example.charityapp.entities.Don;
import org.example.charityapp.entities.Partenaire;
import org.example.charityapp.entities.User;
import org.example.charityapp.repositories.ActionChariteRepository;
import org.example.charityapp.repositories.DonRepository;
import org.example.charityapp.repositories.PartenaireRepository;
import org.example.charityapp.repositories.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserRepository userRepository;
    private final DonRepository donRepository;
    private final PartenaireRepository partenaireRepository;
    private final ActionChariteRepository actionChariteRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminController(UserRepository userRepository,
                           DonRepository donRepository,
                           PartenaireRepository partenaireRepository,
                           ActionChariteRepository actionChariteRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.donRepository = donRepository;
        this.partenaireRepository = partenaireRepository;
        this.actionChariteRepository = actionChariteRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // Dashboard
    @GetMapping("/dashboard")
    public String dashboard() {
        return "admin-dashboard";
    }

    // Liste des utilisateurs
    @GetMapping("/utilisateurs")
    public String afficherUtilisateurs(Model model) {
        model.addAttribute("utilisateurs", userRepository.findAll());
        return "admin-utilisateurs";
    }

    // Formulaire ajout utilisateur
    @GetMapping("/utilisateur/nouveau")
    public String afficherFormAjoutUtilisateur(Model model) {
        model.addAttribute("user", new User());
        return "admin-ajouter-utilisateur";
    }

    // Traitement ajout utilisateur
    @PostMapping("/utilisateur/nouveau")
    public String ajouterUtilisateur(@ModelAttribute User user) {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            return "redirect:/admin/utilisateur/nouveau?error=email";
        }
        user.setPassword(passwordEncoder.encode(user.getPassword())); // encodage sécurisé
        userRepository.save(user);
        return "redirect:/admin/utilisateurs";
    }

    // Supprimer utilisateur
    @GetMapping("/user/delete/{id}")
    public String supprimerUtilisateur(@PathVariable Long id) {
        try {
            userRepository.deleteById(id);
        } catch (Exception e) {
            return "redirect:/admin/utilisateurs?error=suppression";
        }
        return "redirect:/admin/utilisateurs";
    }

    // Liste dons
    @GetMapping("/dons")
    public String afficherDons(Model model) {
        model.addAttribute("dons", donRepository.findAll());
        return "admin-dons";
    }

    // Supprimer don
    @GetMapping("/don/delete/{id}")
    public String supprimerDon(@PathVariable Long id) {
        donRepository.deleteById(id);
        return "redirect:/admin/dons";
    }

    // Liste partenaires
    @GetMapping("/partenaires")
    public String afficherPartenaires(Model model) {
        model.addAttribute("partenaires", partenaireRepository.findAll());
        return "admin-partenaires";
    }

    // Supprimer partenaire
    @GetMapping("/partenaire/delete/{id}")
    public String supprimerPartenaire(@PathVariable Long id) {
        partenaireRepository.deleteById(id);
        return "redirect:/admin/partenaires";
    }

    // Liste actions
    @GetMapping("/actions")
    public String afficherActions(Model model) {
        model.addAttribute("actions", actionChariteRepository.findAll());
        return "admin-actions";
    }

    // Supprimer action
    @GetMapping("/action/delete/{id}")
    public String supprimerAction(@PathVariable Long id) {
        actionChariteRepository.deleteById(id);
        return "redirect:/admin/actions";
    }
}
