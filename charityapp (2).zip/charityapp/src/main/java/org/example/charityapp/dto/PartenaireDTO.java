package org.example.charityapp.dto;

import lombok.Data;

@Data
public class PartenaireDTO {
    private Long id;
    private String nom;
    private String secteur; // ✅ attribut requis pour éviter l'erreur
    private String type;
    private String siteWeb;
    private String logoUrl;
    private String description;
}
