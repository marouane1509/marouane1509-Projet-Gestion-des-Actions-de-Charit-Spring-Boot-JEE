package org.example.charityapp.controllers;

import org.example.charityapp.dto.PartenaireDTO;
import org.example.charityapp.services.PartenaireService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/partenaires")
public class PartenaireController {

    @Autowired
    private PartenaireService service;

    // ✅ Ajout : redirection pour /partenaires vers /partenaires/liste
    @GetMapping
    public String redirigerVersListe() {
        return "redirect:/partenaires/liste";
    }

    // 📄 Afficher la liste des partenaires
    @GetMapping("/liste")
    public String afficherListe(Model model) {
        List<PartenaireDTO> partenaires = service.findAll();
        model.addAttribute("partenaires", partenaires);
        return "liste-partenaires";
    }

    // ➕ Formulaire d'ajout
    @GetMapping("/ajouter")
    public String showForm(Model model) {
        model.addAttribute("partenaire", new PartenaireDTO());
        return "ajouter-partenaire";
    }

    // 💾 Enregistrement d’un nouveau partenaire
    @PostMapping("/save")
    public String save(@ModelAttribute("partenaire") PartenaireDTO dto) {
        service.create(dto);
        return "redirect:/partenaires/liste?success";
    }

    // ❌ Suppression (sécurisée pour les admins uniquement)
    @PostMapping("/supprimer/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String supprimerPartenaire(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        service.delete(id);
        redirectAttributes.addFlashAttribute("successMessage", "Partenaire supprimé !");
        return "redirect:/partenaires/liste";
    }
}
