package org.example.charityapp.controllers;

import org.example.charityapp.entities.User;
import org.example.charityapp.repositories.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;
import java.time.format.DateTimeFormatter;

@Controller
public class UserController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // ✅ Formulaire d'inscription
    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    // ✅ Traitement du formulaire d'inscription
    @PostMapping("/register")
    public String processRegister(@ModelAttribute("user") User user, Model model) {
        // Vérifie si un utilisateur avec cet email existe déjà
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            model.addAttribute("error", "Cet email est déjà utilisé.");
            return "register"; // retourne au formulaire d'inscription
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole("USER");
        userRepository.save(user);
        return "redirect:/login"; // redirige vers la page de connexion
    }


    // ✅ Affichage du profil utilisateur connecté
    @GetMapping("/profil")
    public String afficherProfil(Authentication authentication, Model model) {
        if (authentication == null || !(authentication.getPrincipal() instanceof UserDetails)) {
            return "redirect:/login";
        }

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        Optional<User> optionalUser = userRepository.findByEmail(userDetails.getUsername());
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            model.addAttribute("user", user);
            if (user.getDateNaissance() != null) {
                String dateNaissanceStr = user.getDateNaissance().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                model.addAttribute("dateNaissanceStr", dateNaissanceStr);
            } else {
                model.addAttribute("dateNaissanceStr", "Non renseignée");
            }
            return "profil";
        } else {
            return "redirect:/login";
        }


    }
    @GetMapping("/login")
    public String showLoginForm() {
        return "login"; // Ce nom doit correspondre à ton fichier login.html dans /templates
    }

    @GetMapping("/profil/edit")
    public String editProfil(Authentication authentication, Model model) {
        if (authentication == null || !(authentication.getPrincipal() instanceof UserDetails)) {
            return "redirect:/login";
        }
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        Optional<User> optionalUser = userRepository.findByEmail(userDetails.getUsername());
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            model.addAttribute("user", user);
            return "profil-edit";
        } else {
            return "redirect:/login";
        }
    }

    @PostMapping("/profil/edit")
    public String saveProfil(
        @ModelAttribute("user") User userForm,
        @RequestParam(value = "oldPassword", required = false) String oldPassword,
        @RequestParam(value = "newPassword", required = false) String newPassword,
        @RequestParam(value = "confirmPassword", required = false) String confirmPassword,
        Authentication authentication,
        Model model
    ) {
        if (authentication == null || !(authentication.getPrincipal() instanceof UserDetails)) {
            return "redirect:/login";
        }
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        Optional<User> optionalUser = userRepository.findByEmail(userDetails.getUsername());
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            // Met à jour les champs modifiables
            user.setPrenom(userForm.getPrenom());
            user.setNom(userForm.getNom());
            user.setTelephone(userForm.getTelephone());
            user.setDateNaissance(userForm.getDateNaissance());

            // Gestion du mot de passe
            if (oldPassword != null && !oldPassword.isBlank() && newPassword != null && !newPassword.isBlank()) {
                if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
                    model.addAttribute("user", user);
                    model.addAttribute("error", "Ancien mot de passe incorrect.");
                    return "profil-edit";
                }
                if (!newPassword.equals(confirmPassword)) {
                    model.addAttribute("user", user);
                    model.addAttribute("error", "Les nouveaux mots de passe ne correspondent pas.");
                    return "profil-edit";
                }
                user.setPassword(passwordEncoder.encode(newPassword));
            }

            userRepository.save(user);
            return "redirect:/profil?success";
        } else {
            return "redirect:/login";
        }
    }

}
