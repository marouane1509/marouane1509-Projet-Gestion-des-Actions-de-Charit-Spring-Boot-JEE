package org.example.charityapp.controllers;

import org.example.charityapp.dto.ActionChariteDTO;
import org.example.charityapp.entities.Organization;
import org.example.charityapp.repositories.OrganisationRepository;
import org.example.charityapp.services.ActionChariteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/actions")
public class ActionChariteController {

    @Autowired
    private ActionChariteService service;

    @Autowired
    private OrganisationRepository orgRepo;

    // 🔁 Redirection de /actions vers /actions/liste
    @GetMapping
    public String redirectToList() {
        return "redirect:/actions/liste";
    }

    // 🌐 Formulaire d'ajout (interface HTML)
    @GetMapping("/ajouter")
    public String showForm(Model model) {
        model.addAttribute("action", new ActionChariteDTO());
        List<Organization> orgs = orgRepo.findAll();
        model.addAttribute("organisations", orgs);
        return "ajouter-action";
    }

    // 📥 Enregistrement de l'action (formulaire)
    @PostMapping("/save")
    public String saveAction(@ModelAttribute("action") ActionChariteDTO dto) {
        service.createAction(dto);
        return "redirect:/actions/liste?success";
    }

    // 📋 Affichage de la liste des actions (HTML)
    @GetMapping("/liste")
    public String afficherListe(Model model) {
        List<ActionChariteDTO> actions = service.getAllActions();
        model.addAttribute("actions", actions);
        return "liste-actions";
    }

    // ✅ 🔐 Supprimer une action (interface HTML sécurisée)
    @PostMapping("/supprimer/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String supprimerAction(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        service.deleteAction(id);
        redirectAttributes.addFlashAttribute("successMessage", "Action supprimée !");
        return "redirect:/actions/liste";
    }

    // 🔁 Modifier une action (REST API)
    @ResponseBody
    @PutMapping("/api/{id}")
    public ActionChariteDTO updateAction(@PathVariable Long id, @RequestBody ActionChariteDTO dto) {
        return service.updateAction(id, dto);
    }

    // ❌ Supprimer une action (REST API)
    @ResponseBody
    @DeleteMapping("/api/{id}")
    public void deleteAction(@PathVariable Long id) {
        service.deleteAction(id);
    }

    // 🔄 Obtenir toutes les actions (REST - JSON)
    @ResponseBody
    @GetMapping("/api")
    public List<ActionChariteDTO> getAllActions() {
        return service.getAllActions();
    }

    // 🔍 Obtenir une action spécifique (REST - JSON)
    @ResponseBody
    @GetMapping("/api/{id}")
    public ActionChariteDTO getActionById(@PathVariable Long id) {
        return service.getById(id);
    }
}
