package org.example.charityapp;

import org.example.charityapp.entities.User;
import org.example.charityapp.repositories.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class CharityAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(CharityAppApplication.class, args);
    }

    @Bean
    CommandLineRunner run(UserRepository userRepository, BCryptPasswordEncoder encoder) {
        return args -> {
            if (userRepository.findByEmail("admin@admin.com").isEmpty()) {
                User admin = new User();
                admin.setNom("Admin");
                admin.setPrenom("Super");
                admin.setEmail("admin@admin.com");
                admin.setPassword(encoder.encode("1234"));
                admin.setRole("ADMIN");
                userRepository.save(admin);
            }
        };
    }
}
