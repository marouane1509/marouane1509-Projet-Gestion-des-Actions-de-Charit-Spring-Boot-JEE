package org.example.charityapp.mappers;

import org.example.charityapp.dto.DonDTO;
import org.example.charityapp.entities.Don;

import java.time.LocalDateTime;

public class DonMapper {

    public static Don dtoToEntity(DonDTO dto) {
        Don don = new Don();
        don.setMontant(dto.getMontant());
        don.setMethodePaiement(dto.getMethodePaiement());
        don.setDateDon(LocalDateTime.now()); // Date générée automatiquement
        return don;
    }

    public static DonDTO entityToDto(Don don) {
        DonDTO dto = new DonDTO();
        dto.setMontant(don.getMontant());
        dto.setMethodePaiement(don.getMethodePaiement());
        dto.setDateDon(don.getDateDon());
        return dto;
    }
}
