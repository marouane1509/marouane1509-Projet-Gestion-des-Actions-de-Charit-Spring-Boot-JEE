package org.example.charityapp.services;

import jakarta.annotation.PostConstruct;
import org.example.charityapp.entities.User;
import org.example.charityapp.repositories.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class DataInitializer {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostConstruct
    public void init() {
        String adminEmail = "admin@example.com";

        if (userRepository.findByEmail(adminEmail).isEmpty()) {
            User admin = new User();
            admin.setPrenom("Super");
            admin.setNom("Admin");
            admin.setEmail(adminEmail);
            admin.setPassword(passwordEncoder.encode("admin123")); // mot de passe encodé
            admin.setRole("ADMIN");
            admin.setTelephone("0600000000");
            admin.setSexe("Homme");
            admin.setDateNaissance(LocalDate.of(1990, 1, 1));

            userRepository.save(admin);
            System.out.println("✅ Admin créé : " + adminEmail);
        }
    }
}
