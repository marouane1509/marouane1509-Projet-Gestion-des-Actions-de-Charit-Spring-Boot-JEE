package org.example.charityapp.services;

import org.example.charityapp.dto.PartenaireDTO;
import org.example.charityapp.entities.Partenaire;
import org.example.charityapp.mappers.PartenaireMapper;
import org.example.charityapp.repositories.PartenaireRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PartenaireService {

    @Autowired
    private PartenaireRepository repository;

    public PartenaireDTO create(PartenaireDTO dto) {
        Partenaire partenaire = PartenaireMapper.dtoToEntity(dto);
        return PartenaireMapper.entityToDto(repository.save(partenaire));
    }

    public List<PartenaireDTO> findAll() {
        return repository.findAll().stream()
                .map(PartenaireMapper::entityToDto)
                .collect(Collectors.toList());
    }

    // ✅ Nouvelle méthode à ajouter pour suppression
    public void delete(Long id) {
        repository.deleteById(id);
    }
}
