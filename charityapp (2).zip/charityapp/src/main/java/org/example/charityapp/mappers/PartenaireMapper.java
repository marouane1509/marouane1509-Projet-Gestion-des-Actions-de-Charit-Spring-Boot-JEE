package org.example.charityapp.mappers;

import org.example.charityapp.dto.PartenaireDTO;
import org.example.charityapp.entities.Partenaire;

public class PartenaireMapper {

    public static Partenaire dtoToEntity(PartenaireDTO dto) {
        Partenaire partenaire = new Partenaire();
        partenaire.setNom(dto.getNom());
        partenaire.setType(dto.getType());
        partenaire.setSiteWeb(dto.getSiteWeb());
        partenaire.setLogoUrl(dto.getLogoUrl());
        partenaire.setDescription(dto.getDescription());
        return partenaire;
    }

    public static PartenaireDTO entityToDto(Partenaire partenaire) {
        PartenaireDTO dto = new PartenaireDTO();
        dto.setId(partenaire.getId());
        dto.setNom(partenaire.getNom());
        dto.setType(partenaire.getType());
        dto.setSiteWeb(partenaire.getSiteWeb());
        dto.setLogoUrl(partenaire.getLogoUrl());
        dto.setDescription(partenaire.getDescription());
        return dto;
    }
}
