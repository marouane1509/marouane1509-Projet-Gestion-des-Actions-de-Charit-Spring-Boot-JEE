package org.example.charityapp.controllers;

import org.example.charityapp.dto.DonDTO;
import org.example.charityapp.entities.Don;
import org.example.charityapp.services.DonService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/dons")
public class DonController {

    private final DonService donService;

    public DonController(DonService donService) {
        this.donService = donService;
    }

    @GetMapping
    public String afficherDons(Model model) {
        model.addAttribute("dons", donService.getAllDons());
        return "liste";
    }

    @GetMapping("/ajouter")
    public String afficherFormulaireAjout(Model model) {
        model.addAttribute("donDTO", new DonDTO());
        return "ajouterDon";
    }

    @PostMapping("/ajouter")
    public String ajouterDon(@ModelAttribute("donDTO") DonDTO donDTO, RedirectAttributes redirectAttributes) {
        donService.createDonFromDto(donDTO);
        redirectAttributes.addFlashAttribute("successMessage", "Le don a été ajouté avec succès !");
        return "redirect:/dons";
    }

    @PostMapping("/supprimer/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String supprimerDon(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        donService.deleteDon(id);
        redirectAttributes.addFlashAttribute("successMessage", "Don supprimé !");
        return "redirect:/dons";
    }
}
