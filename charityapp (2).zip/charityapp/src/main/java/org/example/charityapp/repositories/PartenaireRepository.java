package org.example.charityapp.repositories;

import org.example.charityapp.entities.Partenaire;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PartenaireRepository extends JpaRepository<Partenaire, Long> {
}
