package org.example.charityapp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.ui.Model;

@Controller
public class StaticPageController {

    @GetMapping("/mission")
    public String mission() {
        return "mission";
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact";
    }

    @GetMapping("/en-savoir-plus")
    public String enSavoirPlus() {
        return "en-savoir-plus";
    }

    @PostMapping("/contact")
    public String handleContactForm(@ModelAttribute ContactForm form, Model model) {
        // Ici tu peux traiter le message (envoi mail, sauvegarde, etc.)
        model.addAttribute("success", true);
        return "contact";
    }

    // Classe interne simple pour le formulaire de contact
    public static class ContactForm {
        private String name;
        private String email;
        private String subject;
        private String message;
        // Getters et setters
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getSubject() { return subject; }
        public void setSubject(String subject) { this.subject = subject; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
    }
}
