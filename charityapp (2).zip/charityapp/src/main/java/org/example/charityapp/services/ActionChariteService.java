package org.example.charityapp.services;

import org.example.charityapp.dto.ActionChariteDTO;
import org.example.charityapp.entities.ActionCharite;
import org.example.charityapp.entities.Organization;
import org.example.charityapp.mappers.ActionChariteMapper;
import org.example.charityapp.repositories.ActionChariteRepository;
import org.example.charityapp.repositories.OrganisationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ActionChariteService {

    @Autowired
    private ActionChariteRepository actionRepo;

    @Autowired
    private OrganisationRepository orgRepo;

    public List<ActionChariteDTO> getAllActions() {
        return actionRepo.findAll()
                .stream()
                .map(ActionChariteMapper::toDTO)
                .collect(Collectors.toList());
    }

    public ActionChariteDTO createAction(ActionChariteDTO dto) {
        Organization org = null;
        if (dto.getOrganizationId() != null && dto.getOrganizationId() > 0) {
            org = orgRepo.findById(dto.getOrganizationId())
                .orElseThrow(() -> new RuntimeException("Organization not found"));
        } else if (dto.getOrganizationName() != null && !dto.getOrganizationName().isBlank()) {
            org = orgRepo.findAll().stream()
                .filter(o -> o.getNom().equalsIgnoreCase(dto.getOrganizationName().trim()))
                .findFirst()
                .orElse(null);
            if (org == null) {
                // Création automatique de l'organisation si elle n'existe pas
                org = new Organization();
                org.setNom(dto.getOrganizationName().trim());
                org.setAdresseLegale("Adresse à compléter");
                org.setNumeroFiscal("A_COMPLETER_" + System.currentTimeMillis());
                org.setContactPrincipal("A compléter");
                org.setLogoUrl("");
                org.setDescription("");
                org.setEstApprouvee(false);
                org = orgRepo.save(org);
            }
        } else {
            throw new RuntimeException("Organization must be specified");
        }
        ActionCharite action = ActionChariteMapper.toEntity(dto, org);
        return ActionChariteMapper.toDTO(actionRepo.save(action));
    }

    public ActionChariteDTO getById(Long id) {
        ActionCharite action = actionRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Action not found"));
        return ActionChariteMapper.toDTO(action);
    }

    public void deleteAction(Long id) {
        actionRepo.deleteById(id);
    }

    public ActionChariteDTO updateAction(Long id, ActionChariteDTO dto) {
        ActionCharite action = actionRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Action not found"));

        action.setTitre(dto.getTitre());
        action.setDescription(dto.getDescription());
        action.setDate(dto.getDate());
        action.setLieu(dto.getLieu());
        action.setObjectifCollecte(dto.getObjectifCollecte());
        action.setMontantActuel(dto.getMontantActuel());
        action.setMediaUrl(dto.getMediaUrl());
        action.setEstArchivee(dto.isEstArchivee());

        return ActionChariteMapper.toDTO(actionRepo.save(action));
    }
}
