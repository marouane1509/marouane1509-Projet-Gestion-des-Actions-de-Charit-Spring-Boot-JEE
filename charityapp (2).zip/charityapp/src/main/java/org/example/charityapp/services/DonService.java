package org.example.charityapp.services;

import org.example.charityapp.dto.DonDTO;
import org.example.charityapp.entities.Don;
import org.example.charityapp.mappers.DonMapper;
import org.example.charityapp.repositories.DonRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DonService {

    private final DonRepository donRepository;

    public DonService(DonRepository donRepository) {
        this.donRepository = donRepository;
    }

    // Récupérer tous les dons (entités)
    public List<Don> getAllDons() {
        return donRepository.findAll();
    }

    // Récupérer un don par son ID
    public Optional<Don> getDonById(Long id) {
        return donRepository.findById(id);
    }

    // Créer un don à partir d’une entité
    public Don createDon(Don don) {
        return donRepository.save(don);
    }

    // Créer un don à partir d’un DonDTO
    public Don createDonFromDto(DonDTO dto) {
        Don don = DonMapper.dtoToEntity(dto);
        return donRepository.save(don);
    }

    // Supprimer un don par ID
    public void deleteDon(Long id) {
        donRepository.deleteById(id);
    }

    // Récupérer tous les dons sous forme de DTOs
    public List<DonDTO> getAllDonDTOs() {
        return donRepository.findAll().stream()
                .map(DonMapper::entityToDto)
                .collect(Collectors.toList());
    }
}
